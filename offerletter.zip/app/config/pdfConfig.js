export const PDF_CONFIG = {
  scale: 2,
  quality: 1.0,
  margin: {
    top: 30,
    bottom: 30,
    left: 30,
    right: 30
  }
};
