// adminEmails.js
// export const ADMIN_CREDENTIALS = [
//   { email: "lokaci@company.com", password: "lokaci123", name: 'Lokaci' },
//   { email: "harshit@lokaci.com", password: "harshit123", name: 'Harshit' },
// ];
